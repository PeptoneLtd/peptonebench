import pandas as pd
import os
import json

data = pd.read_csv('PeptoneDB-Integrative.csv')

labels = list(data['label'])
sequences = list(data['sequence'])
gscores = list(data['gscores'])

for i in range(len(data)):

    os.mkdir(labels[i])
    arr1=[]
    arr2=[]
    
    for aa, score in zip(sequences[i], json.loads(gscores[i])):
        
        arr1.append(aa)
        arr2.append(score)
        
    df = pd.DataFrame()
    df['aa'] = arr1
    df['g_score'] = arr2
    df.to_csv(labels[i]+'/adopt2_gscores.csv', index=False, na_rep="nan")

